# Lumera Laravel Migration

This project has been migrated to Laravel 10. Follow these steps to get started:

## prerequisites
- PHP 8.1 or higher
- Composer
- Database (MySQL/MariaDB)

## setup
1.  **Database Configuration**:
    - Create a new database (e.g., `lumera_laravel`).
    - Open `.env` file and update your database credentials:
      ```env
      DB_CONNECTION=mysql
      DB_HOST=127.0.0.1
      DB_PORT=3306
      DB_DATABASE=lumera_laravel
      DB_USERNAME=root
      DB_PASSWORD=
      ```

2.  **Run Migrations**:
    - Run the following command to create tables:
      ```bash
      php artisan migrate
      ```

3.  **Import Data** (Optional but Recommended):
    - You can import your original data (products, users) using a custom script or by manually inserting SQL. 
    - Note that table schemas are slightly adjusted for Laravel conventions (e.g., `users.password` instead of `password_hash`).

4.  **Run the Application**:
    - Start the development server:
      ```bash
      php artisan serve
      ```
    - Visit `http://localhost:8000`.

## structure
- **Models**: Located in `app/Models/`.
- **Controllers**: Located in `app/Http/Controllers/`.
- **Views**: Located in `resources/views/`. Uses Blade templating.
- **Routes**: Defined in `routes/web.php`.
- **Assets**: Public assets (CSS, JS, Images) are in `public/`.

## admin access
- To make a user an admin, register an account and then manually update the `is_admin` column to `1` in your database `users` table.
