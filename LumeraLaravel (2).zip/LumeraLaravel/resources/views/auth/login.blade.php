@extends('layouts.app')

@section('title', 'Login - LUMERA')

@section('content')
<div class="container" style="max-width: 500px; margin-top: 50px;">
    <h1>Login</h1>
    
    @if ($errors->any())
        <div class="message error">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card glass-card">
        <form action="{{ route('login') }}" method="POST">
            @csrf
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" name="email" id="email" value="{{ old('email') }}" required autofocus>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" required>
            </div>

            <button type="submit" class="btn btn-primary btn-block">Login</button>
            
            <p style="margin-top: 15px; text-align: center;">
                Don't have an account? <a href="{{ route('register') }}">Register here</a>
            </p>
        </form>
    </div>
</div>
@endsection
