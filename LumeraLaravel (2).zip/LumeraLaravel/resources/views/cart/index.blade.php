@extends('layouts.app')

@section('title', 'Shopping Cart - LUMERA')

@section('content')
<div class="container">
    <h1>Shopping Cart</h1>

    @if($cartItems->isEmpty())
        <div class="empty-cart">
            <p>Your cart is empty</p>
            <a href="{{ route('products.index') }}" class="btn btn-primary">Continue Shopping</a>
        </div>
    @else
        <form action="{{ route('cart.update') }}" method="POST" class="cart-form">
            @csrf
            
            <div class="cart-items">
                @foreach($cartItems as $item)
                <div class="cart-item">
                    <div class="item-image">
                        <img src="{{ $item->product->primary_image_url }}" alt="{{ $item->product->title }}">
                    </div>
                    <div class="item-details">
                        <h3>{{ $item->product->title }}</h3>
                        <p class="item-price">{{ number_format($item->product->price, 2) }}</p>
                    </div>
                    <div class="item-quantity">
                        <input type="number" 
                               name="quantities[{{ $item->id }}]" 
                               value="{{ $item->quantity }}" 
                               min="1" 
                               max="{{ $item->product->quantity }}" 
                               class="qty-input">
                    </div>
                    <div class="item-total">
                        {{ number_format($item->product->price * $item->quantity, 2) }}
                    </div>
                    <div class="item-actions">
                        {{-- Remove button handled via separate form or JS --}}
                        <button type="submit" form="remove-form-{{ $item->id }}" class="btn btn-danger btn-small" onclick="return confirm('Remove this item?')">Remove</button>
                    </div>
                </div>
                @endforeach
            </div>

            <div class="cart-summary">
                <div class="summary-row">
                    <span>Subtotal:</span>
                    <span>{{ number_format($subtotal, 2) }}</span>
                </div>
                <div class="summary-row">
                    <span>Shipping:</span>
                    <span>$10.00</span>
                </div>
                <div class="summary-row total">
                    <span>Total:</span>
                    <span>{{ number_format($subtotal + 10, 2) }}</span>
                </div>
            </div>

            <div class="cart-actions">
                <button type="submit" class="btn btn-secondary">Update Cart</button>
                <a href="{{ route('checkout.index') }}" class="btn btn-primary">Proceed to Checkout</a>
            </div>
        </form>

        {{-- Separate forms for remove actions (POST/DELETE) --}}
        @foreach($cartItems as $item)
            <form id="remove-form-{{ $item->id }}" action="{{ route('cart.destroy', $item->id) }}" method="POST" style="display: none;">
                @csrf
                @method('DELETE')
            </form>
        @endforeach

    @endif
</div>
@endsection
