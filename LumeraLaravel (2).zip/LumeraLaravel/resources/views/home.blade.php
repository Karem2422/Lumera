@extends('layouts.app')

@section('title', 'LUMERA - Curated Beauty')

@section('content')
    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
            <h2>Curated Beauty, Artisan Excellence</h2>
            <p>A sanctuary of precision-crafted leather, thought-provoking literature, and original masterpieces</p>
            <a href="{{ route('products.index') }}" class="btn btn-primary">Shop Collection</a>
        </div>
    </section>

    <!-- Featured Products -->
    <section class="featured-products">
        <div class="container">
            <h2>Featured Collection</h2>
            <div class="products-grid">
                @forelse($products as $product)
                <div class="product-card">
                    <a href="{{ route('products.show', $product->slug) }}" class="product-card-link">
                        <div class="product-image">
                            <img src="{{ $product->primary_image_url }}" alt="{{ $product->title }}">
                            @if ($product->status == 'sold_out')
                                <span class="sold-out-badge">Sold Out</span>
                            @endif
                        </div>
                        <div class="product-info">
                            <h3>{{ $product->title }}</h3>
                            <p class="product-price">{{ number_format($product->price, 2) }}</p>
                        </div>
                    </a>
                    <div class="product-actions">
                        <a href="{{ route('products.show', $product->slug) }}" class="btn btn-secondary btn-block">View Details</a>
                    </div>
                </div>
                @empty
                    <p>No featured products available at the moment.</p>
                @endforelse
            </div>
        </div>
    </section>
@endsection
