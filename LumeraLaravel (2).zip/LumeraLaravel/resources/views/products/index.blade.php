@extends('layouts.app')

@section('title', 'Products - LUMERA')

@section('content')
    <div class="container">
        <h1>Our Collection</h1>
        
        <!-- Filters -->
        <div class="filters">
            <form method="GET" action="{{ route('products.index') }}" class="filter-form" id="filter-form">
                <div class="filter-group">
                    <input type="text" name="search" id="search-input" placeholder="Search products..." value="{{ request('search') }}">
                </div>
                <div class="filter-group">
                    <select name="category" id="category-select">
                        <option value="">All Categories</option>
                        <option value="bags" {{ request('category') == 'bags' ? 'selected' : '' }}>Bags</option>
                        <option value="books" {{ request('category') == 'books' ? 'selected' : '' }}>Books</option>
                        <option value="paintings" {{ request('category') == 'paintings' ? 'selected' : '' }}>Paintings</option>
                    </select>
                </div>
                @if(request('category') == 'books')
                <div class="filter-group">
                    <select name="genre" id="genre-select">
                        <option value="">All Genres</option>
                        @foreach(['Fiction', 'Romance', 'Mystery', 'Science Fiction', 'Fantasy', 'Non-Fiction', 'Biography', 'Self-Help', 'History', 'Poetry'] as $genre)
                            <option value="{{ $genre }}" {{ request('genre') == $genre ? 'selected' : '' }}>{{ $genre }}</option>
                        @endforeach
                    </select>
                </div>
                @endif
                <div class="filter-group">
                    <input type="number" name="min_price" id="min-price" placeholder="Min price" value="{{ request('min_price') }}">
                    <input type="number" name="max_price" id="max-price" placeholder="Max price" value="{{ request('max_price') }}">
                </div>
                <div class="filter-group">
                    <select name="status" id="status-select">
                        <option value="">All Status</option>
                        <option value="available" {{ request('status') == 'available' ? 'selected' : '' }}>Available</option>
                        <option value="sold_out" {{ request('status') == 'sold_out' ? 'selected' : '' }}>Sold Out</option>
                    </select>
                </div>
                <div class="filter-group">
                    <select name="sort" id="sort-select" onchange="this.form.submit()">
                        <option value="newest" {{ request('sort') == 'newest' ? 'selected' : '' }}>Newest First</option>
                        <option value="price_asc" {{ request('sort') == 'price_asc' ? 'selected' : '' }}>Price: Low to High</option>
                        <option value="price_desc" {{ request('sort') == 'price_desc' ? 'selected' : '' }}>Price: High to Low</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-secondary">Apply Filters</button>
                <a href="{{ route('products.index') }}" class="btn btn-outline">Clear</a>
            </form>
        </div>

        <!-- Products Grid -->
        <div class="products-grid">
            @forelse($products as $product)
            <div class="product-card">
                <a href="{{ route('products.show', $product->slug) }}" class="product-card-link">
                    <div class="product-image">
                        <img src="{{ $product->primary_image_url }}" alt="{{ $product->title }}">
                        @if ($product->status == 'sold_out')
                            <span class="sold-out-badge">Sold Out</span>
                        @endif
                        
                        {{-- Wishlist Logic Placehoder --}}
                        {{-- <form action="..." method="POST" class="wishlist-form">...</form> --}}
                    </div>
                    <div class="product-info">
                        <h3>{{ $product->title }}</h3>
                        <p class="product-price">{{ number_format($product->price, 2) }}</p>
                        <p class="product-status {{ $product->status }}">
                            {{ ucfirst($product->status) }}
                        </p>
                    </div>
                </a>
                <div class="product-actions">
                    <a href="{{ route('products.show', $product->slug) }}" class="btn btn-secondary btn-block">View Details</a>
                </div>
            </div>
            @empty
                <p class="no-products">No products found matching your criteria.</p>
            @endforelse
        </div>

        <!-- Pagination -->
        <div class="pagination">
            {{ $products->appends(request()->query())->links() }}
        </div>
    </div>
@endsection
