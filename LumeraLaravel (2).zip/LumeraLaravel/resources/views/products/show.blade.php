@extends('layouts.app')

@section('title', $product->title . ' - LUMERA')

@section('content')
<div class="container">
    <div class="product-detail">
        <div class="product-gallery">
            <div class="main-image">
                <img src="{{ $product->primary_image_url }}" alt="{{ $product->title }}" id="main-product-image">
            </div>
            @if($product->images->count() > 1)
            <div class="image-thumbnails">
                @foreach($product->images as $image)
                    <img src="{{ $image->url }}" 
                         alt="{{ $product->title }}" 
                         class="thumbnail {{ $image->is_primary ? 'active' : '' }}"
                         style="cursor: pointer;"
                         onclick="document.getElementById('main-product-image').src = this.src; document.querySelectorAll('.thumbnail').forEach(el => el.classList.remove('active')); this.classList.add('active');"
                    >
                @endforeach
            </div>
            @endif
        </div>

        <div class="product-info">
            <h1>{{ $product->title }}</h1>
            <p class="product-price">{{ number_format($product->price, 2) }}</p>
            <p class="product-status {{ $product->status }}">
                {{ ucfirst($product->status) }} ({{ $product->quantity }} left)
            </p>

            {{-- Category Metadata --}}
            @if($product->category == 'books')
                <div class="product-metadata">
                    <h3>Book Details</h3>
                    <div class="metadata-grid">
                        @if($product->author_name) <div><strong>Author:</strong> {{ $product->author_name }}</div> @endif
                        @if($product->genre) <div><strong>Genre:</strong> {{ $product->genre }}</div> @endif
                        @if($product->publication_year) <div><strong>Year:</strong> {{ $product->publication_year }}</div> @endif
                        @if($product->pages) <div><strong>Pages:</strong> {{ $product->pages }}</div> @endif
                    </div>
                </div>
            @elseif($product->category == 'paintings')
                <div class="product-metadata">
                    <h3>Artwork Details</h3>
                     <div class="metadata-grid">
                        @if($product->artist_name) <div><strong>Artist:</strong> {{ $product->artist_name }}</div> @endif
                        @if($product->painting_size) <div><strong>Size:</strong> {{ $product->painting_size }}</div> @endif
                    </div>
                </div>
            @endif

            <div class="product-description">
                <h3>Description</h3>
                <p>{!! nl2br(e($product->description)) !!}</p>
            </div>

            @if($product->status == 'available' && $product->quantity > 0)
                <form action="{{ route('cart.store') }}" method="POST" class="add-to-cart-form">
                    @csrf
                    <input type="hidden" name="product_id" value="{{ $product->id }}">
                    <div class="quantity-selector">
                        <label for="quantity">Quantity:</label>
                        <div class="qty-controls">
                            <button type="button" class="qty-btn" onclick="let q = document.getElementById('quantity'); if(q.value > 1) q.value--;">−</button>
                            <input type="number" id="quantity" name="quantity" value="1" min="1" max="{{ $product->quantity }}">
                            <button type="button" class="qty-btn" onclick="let q = document.getElementById('quantity'); if(q.value < {{ $product->quantity }}) q.value++;">+</button>
                        </div>
                    </div>
                    <div class="action-buttons">
                        <button type="submit" class="btn btn-secondary">Add to Cart</button>
                        {{-- Buy Now logic would typically submit form to checkout route or add to cart then redirect --}}
                    </div>
                </form>
            @else
                <p class="sold-out-message">This product is currently sold out.</p>
            @endif
        </div>
    </div>

    <!-- Related Products -->
    @if($relatedProducts->count() > 0)
    <section class="related-products">
        <h2>You Might Also Like</h2>
        <div class="products-grid">
            @foreach($relatedProducts as $related)
            <div class="product-card">
                <a href="{{ route('products.show', $related->slug) }}" class="product-card-link">
                    <div class="product-image">
                        <img src="{{ $related->primary_image_url }}" alt="{{ $related->title }}">
                    </div>
                    <div class="product-info">
                        <h3>{{ $related->title }}</h3>
                        <p class="product-price">{{ number_format($related->price, 2) }}</p>
                    </div>
                </a>
            </div>
            @endforeach
        </div>
    </section>
    @endif
</div>
@endsection
