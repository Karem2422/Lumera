<header class="header">
    <nav class="nav">
        <div class="nav-brand">
            <h1><a href="{{ route('home') }}">LUMERA</a></h1>
        </div>

        <div class="nav-search">
            <form action="{{ route('products.index') }}" method="GET" class="search-form">
                <input type="text" name="search" placeholder="Search..." value="{{ request('search') }}">
                <button type="submit" aria-label="Search">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="11" cy="11" r="8"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                </button>
            </form>
        </div>

        <ul class="nav-links">
            <li><a href="{{ route('home') }}" class="{{ request()->routeIs('home') ? 'active' : '' }}">Home</a></li>
            <li><a href="{{ route('products.index') }}" class="{{ request()->routeIs('products.index') ? 'active' : '' }}">Products</a></li>
            
            @auth
                {{-- Wishlist route not yet defined but link can exist --}}
                <li><a href="#" class="">Wishlist</a></li>

                @can('admin')
                    <li><a href="{{ route('admin.dashboard') }}">Admin</a></li>
                @else
                    <li><a href="{{ route('my-orders') }}" class="{{ request()->routeIs('my-orders') ? 'active' : '' }}">My Orders</a></li>
                @endcan

                <li>
                    <a href="{{ route('cart.index') }}" class="cart-link {{ request()->routeIs('cart.index') ? 'active' : '' }}">
                        <span class="cart-icon">🛒</span>
                        <span class="cart-label">Cart</span>
                        @php
                            $cartCount = auth()->user()->cartItems->sum('quantity');
                        @endphp
                        @if ($cartCount > 0)
                            <span class="cart-badge">{{ $cartCount }}</span>
                        @endif
                    </a>
                </li>
                <li>
                    <form action="{{ route('logout') }}" method="POST" style="display:inline;">
                        @csrf
                        <button type="submit" style="background:none; border:none; cursor:pointer; color:inherit; font:inherit;">Logout</button>
                    </form>
                </li>
            @else
                <li><a href="{{ route('login') }}" class="{{ request()->routeIs('login') ? 'active' : '' }}">Login</a></li>
                <li><a href="{{ route('register') }}" class="{{ request()->routeIs('register') ? 'active' : '' }}">Register</a></li>
            @endauth
        </ul>
    </nav>
</header>
