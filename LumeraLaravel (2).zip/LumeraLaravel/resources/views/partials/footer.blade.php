<footer class="footer">
    <div class="container">
        <div class="footer-grid">
            <div class="footer-brand">
                <h3>LUMERA</h3>
                <p>Handcrafted leather goods inspired by desert hues and timeless craftsmanship. Every stitch tells a story.</p>
                <div class="social-links">
                    <a href="https://www.instagram.com/needle_and_thread.ye?igsh=YnNnMnB3Nnl5aHk3&utm_source=qr" aria-label="Instagram" class="social-icon" target="_blank">IG</a>
                    <a href="https://pin.it/6mO8SNOUO" aria-label="Pinterest" class="social-icon" target="_blank">PI</a>
                    <a href="https://www.facebook.com/share/1D3dkN3rqF/?mibextid=wwXIfr" aria-label="Facebook" class="social-icon" target="_blank">FB</a>
                </div>
            </div>
            <div class="footer-column">
                <h4>Explore</h4>
                <ul>
                    <li><a href="{{ route('products.index') }}">Shop Products</a></li>
                    <li><a href="{{ route('about') }}">About Us</a></li>
                    <li><a href="{{ route('cart.index') }}">Your Cart</a></li>
                    <li><a href="{{ route('register') }}">Create Account</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h4>Customer Care</h4>
                <ul>
                    {{-- Define these routes later --}}
                    <li><a href="{{ url('/shipping-delivery') }}">Shipping &amp; Delivery</a></li>
                    <li><a href="{{ url('/returns-exchanges') }}">Returns &amp; Exchanges</a></li>
                    <li><a href="{{ url('/care-instructions') }}">Care Instructions</a></li>
                    <li><a href="{{ url('/faqs') }}">FAQs</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h4><a href="{{ route('stay-in-touch') }}">Stay in touch</a></h4>
                <p>Join our newsletter for new releases, behind-the-scenes stories, and exclusive offers.</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; {{ date('Y') }} LUMERA. All rights reserved.</p>
            <div class="footer-meta">
                <a href="{{ url('/privacy-policy') }}">Privacy Policy</a>
                <span>&middot;</span>
                <a href="{{ url('/terms-of-service') }}">Terms of Service</a>
                <span>&middot;</span>
                <a href="mailto:hello@lumera.com">hello@lumera.com</a>
            </div>
        </div>
    </div>
</footer>
