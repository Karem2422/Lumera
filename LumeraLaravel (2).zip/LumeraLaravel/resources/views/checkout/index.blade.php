@extends('layouts.app')

@section('title', 'Checkout - LUMERA')

@section('content')
<div class="container">
    <h1>Checkout</h1>

    @if($errors->any())
        <div class="message error">
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="checkout-layout">
        <div class="checkout-form">
            <h2>Shipping Information</h2>
            <form action="{{ route('checkout.store') }}" method="POST">
                @csrf
                <div class="form-group">
                    <input type="text" name="name" placeholder="Full Name" value="{{ old('name', auth()->user()->name) }}" required>
                </div>
                <div class="form-group">
                    <input type="email" name="email" placeholder="Email Address" value="{{ old('email', auth()->user()->email) }}" required>
                </div>
                <div class="form-group">
                    <input type="text" name="phone" placeholder="Phone Number" value="{{ old('phone') }}" required>
                </div>
                <div class="form-group">
                    <textarea name="address" placeholder="Shipping Address" rows="4" required>{{ old('address') }}</textarea>
                </div>
                
                <h2>Payment Method</h2>
                <div class="payment-method">
                    <div class="payment-option">
                        <input type="radio" id="paypal" name="payment_method" value="paypal" {{ old('payment_method', 'paypal') == 'paypal' ? 'checked' : '' }} onchange="togglePaymentMethod()">
                        <label for="paypal">PayPal</label>
                    </div>
                    <div class="payment-option">
                        <input type="radio" id="credit_card" name="payment_method" value="credit_card" {{ old('payment_method') == 'credit_card' ? 'checked' : '' }} onchange="togglePaymentMethod()">
                        <label for="credit_card">Credit Card</label>
                    </div>

                    <div id="paypal-info" class="payment-info">
                        <p class="payment-note">You will be redirected to PayPal to complete your payment.</p>
                    </div>
                    
                    <div id="credit-card-info" class="payment-info" style="display: none; margin-top: 1rem;">
                        <div class="form-group">
                            <input type="text" name="card_number" id="card_number" placeholder="Card Number" maxlength="19" class="form-control">
                        </div>
                        <div style="display: flex; gap: 1rem;">
                            <div class="form-group" style="flex: 1;">
                                <input type="text" name="card_expiry" id="card_expiry" placeholder="MM/YY" maxlength="5" class="form-control">
                            </div>
                            <div class="form-group" style="flex: 1;">
                                <input type="text" name="card_cvc" id="card_cvc" placeholder="CVC" maxlength="4" class="form-control">
                            </div>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-block" style="margin-top: 20px;">Place Order</button>
            </form>
        </div>

        <div class="order-summary">
            <h2>Order Summary</h2>
            <div class="summary-items">
                @foreach($cartItems as $item)
                <div class="summary-item">
                    <div class="item-image">
                        <img src="{{ $item->product->primary_image_url }}" alt="{{ $item->product->title }}">
                    </div>
                    <div class="item-info">
                        <h4>{{ $item->product->title }}</h4>
                        <p>Qty: {{ $item->quantity }}</p>
                        <p>{{ number_format($item->product->price, 2) }}</p>
                    </div>
                </div>
                @endforeach
            </div>
            
            <div class="summary-totals">
                <div class="summary-row">
                    <span>Subtotal:</span>
                    <span>{{ number_format($subtotal, 2) }}</span>
                </div>
                <div class="summary-row">
                    <span>Shipping:</span>
                    <span>{{ number_format($shipping, 2) }}</span>
                </div>
                <div class="summary-row total">
                    <span>Total:</span>
                    <span>{{ number_format($total, 2) }}</span>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
    function togglePaymentMethod() {
        const selectedMethod = document.querySelector('input[name="payment_method"]:checked').value;
        const creditCardInfo = document.getElementById('credit-card-info');
        const paypalInfo = document.getElementById('paypal-info'); // If exists
        
        if (selectedMethod === 'credit_card') {
            creditCardInfo.style.display = 'block';
            if(paypalInfo) paypalInfo.style.display = 'none';
        } else {
            creditCardInfo.style.display = 'none';
            if(paypalInfo) paypalInfo.style.display = 'block';
        }
    }
    // Run on load
    document.addEventListener('DOMContentLoaded', togglePaymentMethod);
</script>
@endpush
@endsection
