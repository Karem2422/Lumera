<?php

namespace App\Http\Controllers;

use App\Models\NewsletterSubscriber;
use Illuminate\Http\Request;

class NewsletterController extends Controller
{
    public function store(Request $request)
    {
        $validated = $request->validate([
            'email' => 'required|email|unique:newsletter_subscribers,email',
            'name' => 'nullable|string'
        ]);

        NewsletterSubscriber::create($validated);

        return back()->with('success', 'You have been subscribed to our newsletter!');
    }
}
