<?php

namespace App\Http\Controllers;

use App\Models\CartItem;
use App\Models\InventoryLog;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderStatusHistory;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class CheckoutController extends Controller
{
    public function index()
    {
        $cartItems = Auth::user()->cartItems()->with('product')->get();
        if ($cartItems->isEmpty()) {
            return redirect()->route('cart.index')->with('error', 'Cart is empty.');
        }

        $subtotal = $cartItems->sum(function ($item) {
            return $item->product->price * $item->quantity;
        });
        $shipping = 10.00;
        $total = $subtotal + $shipping;

        return view('checkout.index', compact('cartItems', 'subtotal', 'shipping', 'total'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:100',
            'email' => 'required|email|max:255',
            'phone' => ['required', 'string', 'regex:/^[0-9]{9}$/', function ($attribute, $value, $fail) {
                // Custom rule: Starts with 77, 78, 71, 73, or 70
                if (!preg_match('/^(77|78|71|73|70)/', $value)) {
                    $fail('Phone number must start with 77, 78, 71, 73, or 70.');
                }
            }],
            'address' => 'required|string',
            'payment_method' => 'required|in:paypal,credit_card',
            // if credit card, validate fields
            'card_number' => 'required_if:payment_method,credit_card|numeric|digits_between:13,19',
            'card_expiry' => 'required_if:payment_method,credit_card|date_format:m/y', // format m/y or similar
            'card_cvc' => 'required_if:payment_method,credit_card|numeric|digits_between:3,4',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        // Validate stock
        $cartItems = Auth::user()->cartItems;
        if ($cartItems->isEmpty()) {
            return redirect()->route('products.index')->with('error', 'Cart is empty');
        }

        foreach ($cartItems as $item) {
             if ($item->product->quantity < $item->quantity) {
                 return back()->with('error', "Product {$item->product->title} is out of stock (Requested: {$item->quantity}, Available: {$item->product->quantity})");
             }
        }

        DB::beginTransaction();

        try {
            $subtotal = $cartItems->sum(fn($item) => $item->product->price * $item->quantity);
            $total = $subtotal + 10.00;

            $status = 'pending';
            if ($request->payment_method === 'credit_card') {
                $status = 'paid'; // Simulate payment
            }

            $order = Order::create([
                'user_id' => Auth::id(),
                'name' => $request->name,
                'email' => $request->email,
                'address' => $request->address,
                'total_price' => $total,
                'status' => $status,
                'payment_method' => $request->payment_method,
            ]);

            OrderStatusHistory::create([
                'order_id' => $order->id,
                'changed_by' => Auth::id(), // User themselves initiated it?
                // Actually usually null for system creation, but current user is fine.
                // In old code: recordOrderStatusHistory(..., $user_id, ...)
                'old_status' => null,
                'new_status' => $status,
                'note' => 'Order created',
            ]);

            foreach ($cartItems as $item) {
                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $item->product_id,
                    'quantity' => $item->quantity,
                    'price' => $item->product->price,
                ]);

                // Reduce stock
                $item->product->decrement('quantity', $item->quantity);

                // Inventory Log
                InventoryLog::create([
                    'product_id' => $item->product_id,
                    'product_name' => $item->product->title,
                    'user_id' => Auth::id(),
                    'change_type' => 'order',
                    'quantity_change' => -$item->quantity,
                    'note' => "Order #{$order->id} placed",
                ]);
            }

            // Clear cart
            Auth::user()->cartItems()->delete();

            DB::commit();

            return redirect()->route('checkout.success')->with('order_id', $order->id);

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Order failed: ' . $e->getMessage());
        }
    }

    public function success()
    {
        return view('checkout.success');
    }
}
