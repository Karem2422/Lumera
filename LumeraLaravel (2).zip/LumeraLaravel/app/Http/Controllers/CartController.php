<?php

namespace App\Http\Controllers;

use App\Models\CartItem;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CartController extends Controller
{
    public function index()
    {
        $cartItems = Auth::user()->cartItems()->with('product')->get();
        // Calculate subtotal
        $subtotal = $cartItems->sum(function ($item) {
            return $item->product ? $item->product->price * $item->quantity : 0;
        });

        return view('cart.index', compact('cartItems', 'subtotal'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'product_id' => 'required|exists:products,id',
            'quantity' => 'nullable|integer|min:1',
        ]);

        $quantity = $request->input('quantity', 1);
        $product = Product::findOrFail($request->product_id);

        if ($product->quantity < $quantity) {
             return back()->with('error', 'Not enough stock available.');
        }

        $cartItem = CartItem::where('user_id', Auth::id())
                            ->where('product_id', $request->product_id)
                            ->first();

        if ($cartItem) {
            $cartItem->increment('quantity', $quantity);
        } else {
            CartItem::create([
                'user_id' => Auth::id(),
                'product_id' => $request->product_id,
                'quantity' => $quantity
            ]);
        }

        return redirect()->route('cart.index')->with('success', 'Item added to cart.');
    }

    public function update(Request $request) // Update quantities from cart page
    {
        $request->validate([
            'quantities' => 'required|array',
            'quantities.*' => 'integer|min:1'
        ]);

        foreach ($request->quantities as $id => $qty) {
            $item = CartItem::where('user_id', Auth::id())->where('id', $id)->first();
            if ($item) {
                // optional: check stock
                if ($item->product->quantity >= $qty) {
                    $item->update(['quantity' => $qty]);
                }
            }
        }

        return back()->with('success', 'Cart updated.');
    }

    public function destroy($id)
    {
        $cartItem = CartItem::where('user_id', Auth::id())->where('id', $id)->firstOrFail();
        $cartItem->delete();
        return back()->with('success', 'Item removed.');
    }
}
