<?php

namespace App\Http\Controllers;

use App\Models\Comment;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CommentController extends Controller
{
    public function store(Request $request, Product $product)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:100',
            'email' => 'required|email|max:255',
            'comment' => 'required|string',
        ]);

        $approved = Auth::check() && Auth::user()->is_admin; // Auto approve admin

        $product->comments()->create([
            'user_id' => Auth::id(),
            'name' => $validated['name'],
            'email' => $validated['email'],
            'comment' => $validated['comment'],
            'approved' => $approved,
        ]);

        $message = $approved ? 'Comment added successfully!' : 'Comment submitted for approval!';
        return back()->with('success', $message);
    }
}
