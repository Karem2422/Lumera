<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('slug')->unique();
            $table->enum('category', ['bags', 'books', 'paintings'])->default('bags');
            $table->string('author_name')->nullable();
            $table->integer('publication_year')->nullable();
            $table->string('book_type')->nullable();
            $table->string('genre')->nullable();
            $table->integer('pages')->nullable();
            $table->string('artist_name')->nullable();
            $table->string('painting_size')->nullable();
            $table->text('description');
            $table->decimal('price', 10, 2);
            $table->integer('quantity')->default(0);
            $table->enum('status', ['available', 'sold_out'])->default('available');
            $table->text('tags')->nullable();
            $table->timestamps();
        });

        Schema::create('product_images', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained()->cascadeOnDelete();
            $table->string('filename');
            $table->boolean('is_primary')->default(false);
            // created_at not present in original SQL, create default?
            // Existing SQL doesn't have timestamps for images. We can omit or add them.
            // I'll omit to match SQL exactly or maybe add later.
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('product_images');
        Schema::dropIfExists('products');
    }
};
