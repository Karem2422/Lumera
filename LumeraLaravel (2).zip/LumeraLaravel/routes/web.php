<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\NewsletterController; // Need to create

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Public Routes
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/products', [ProductController::class, 'index'])->name('products.index');
Route::get('/products/{slug}', [ProductController::class, 'show'])->name('products.show');
Route::post('/products/{product:slug}', [App\Http\Controllers\CommentController::class, 'store'])->name('products.comments.store');
Route::get('/about', function () {
    return view('about');
})->name('about');
Route::get('/stay-in-touch', function () {
    return view('stay-in-touch');
})->name('stay-in-touch');

// Static Pages
Route::get('/shipping-delivery', function () { return view('pages.shipping-delivery'); });
Route::get('/returns-exchanges', function () { return view('pages.returns-exchanges'); });
Route::get('/care-instructions', function () { return view('pages.care-instructions'); });
Route::get('/faqs', function () { return view('pages.faqs'); });
Route::get('/privacy-policy', function () { return view('pages.privacy-policy'); });
Route::get('/terms-of-service', function () { return view('pages.terms-of-service'); });

// Newsletter
Route::post('/newsletter', [NewsletterController::class, 'store'])->name('newsletter.store');

// Auth Routes
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::get('/register', [AuthController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [AuthController::class, 'register']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Authenticated Routes
Route::middleware(['auth'])->group(function () {
    // Cart
    Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
    Route::post('/cart', [CartController::class, 'store'])->name('cart.store');
    Route::post('/cart/update', [CartController::class, 'update'])->name('cart.update'); // Form uses POST/PUT
    Route::delete('/cart/{id}', [CartController::class, 'destroy'])->name('cart.destroy');

    // Checkout
    Route::get('/checkout', [CheckoutController::class, 'index'])->name('checkout.index');
    Route::post('/checkout', [CheckoutController::class, 'store'])->name('checkout.store');
    Route::get('/checkout/success', [CheckoutController::class, 'success'])->name('checkout.success');

    // User Orders
    Route::get('/my-orders', function () {
        $orders = auth()->user()->orders()->latest()->get();
        return view('my-orders', compact('orders'));
    })->name('my-orders');
});

// Admin Routes
Route::middleware(['auth', 'can:admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', function () {
        return view('admin.dashboard');
    })->name('dashboard');
    // Add more admin routes here
});
